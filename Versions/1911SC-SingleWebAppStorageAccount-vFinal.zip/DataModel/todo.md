# Tarefas para Desenvolvimento da Aplicação de Competição

- [x] Criar estrutura do projeto .NET 8 Web App
- [x] Implementar modelos de dados para participantes e competição
- [x] Desenvolver interface de usuário para cadastro de participantes
- [x] Implementar lógica de cálculo de pontuação e classificação
- [x] Adicionar funcionalidade de exportação para PDF
- [x] Preparar instruções de implantação no Azure Web App
- [x] Validar a aplicação e documentação
